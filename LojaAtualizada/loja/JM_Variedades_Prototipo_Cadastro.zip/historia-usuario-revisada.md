# História de Usuário Revisada — H04.004

**Sistema/Produto:** JM Variedades  
**Título:** Cadastro de Clientes  
**Módulo/Épico:** Cadastro de Clientes  
**Prioridade:** Alta  
**Código:** H04.004

## História de usuário

> **Como cliente, quero me cadastrar na JM Variedades informando meus dados pessoais e pelo menos um endereço de entrega, para agilizar minhas compras futuras e garantir que meus pedidos sejam entregues corretamente.**

## Critérios de aceite

1. O sistema deve apresentar campos para nome completo, CPF, e-mail, telefone, senha e confirmação de senha.
2. O cadastro deve permitir informar pelo menos um endereço de entrega contendo rua, número, complemento (opcional), bairro, cidade, UF e CEP.
3. CPF e e-mail devem ser tratados como dados únicos no sistema, impedindo cadastros duplicados quando a funcionalidade estiver implementada.
4. O cliente deve poder editar posteriormente seus dados cadastrais e endereços.
5. A tela deve indicar claramente os campos obrigatórios e apresentar mensagens de validação quando os dados estiverem incompletos ou inválidos.
6. O protótipo não realiza gravação de dados; a confirmação serve apenas para demonstrar o fluxo da interface.

## Escopo do protótipo

- Tela de cadastro de cliente.
- Navegação visual.
- Máscaras de CPF, telefone e CEP.
- Validação visual dos campos.
- Botão de criação da conta com confirmação simulada.
- Sem banco de dados, API ou persistência.

## Relação com o documento original

A história mantém o objetivo original de permitir que o cliente informe dados pessoais e endereço(s) de entrega para agilizar compras futuras e garantir a entrega correta. Os dados necessários seguem o documento-base: nome completo, CPF, e-mail, telefone, senha e endereço com rua, número, complemento, bairro, cidade, UF e CEP.
