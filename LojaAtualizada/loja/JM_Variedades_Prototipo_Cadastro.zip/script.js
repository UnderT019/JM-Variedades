const form = document.getElementById("registerForm");
const successMessage = document.getElementById("successMessage");

function onlyDigits(value) {
  return value.replace(/\D/g, "");
}

function formatCPF(value) {
  const digits = onlyDigits(value).slice(0, 11);
  return digits
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

function formatPhone(value) {
  const digits = onlyDigits(value).slice(0, 11);
  if (digits.length <= 10) {
    return digits
      .replace(/(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{4})(\d)/, "$1-$2");
  }
  return digits
    .replace(/(\d{2})(\d)/, "($1) $2")
    .replace(/(\d{5})(\d)/, "$1-$2");
}

function formatCEP(value) {
  return onlyDigits(value).slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");
}

document.getElementById("cpf").addEventListener("input", (e) => {
  e.target.value = formatCPF(e.target.value);
});

document.getElementById("telefone").addEventListener("input", (e) => {
  e.target.value = formatPhone(e.target.value);
});

document.getElementById("cep").addEventListener("input", (e) => {
  e.target.value = formatCEP(e.target.value);
});

document.querySelectorAll(".password-toggle").forEach((button) => {
  button.addEventListener("click", () => {
    const input = document.getElementById(button.dataset.target);
    const visible = input.type === "text";
    input.type = visible ? "password" : "text";
    button.textContent = visible ? "Mostrar" : "Ocultar";
  });
});

function setError(input, message) {
  const field = input.closest(".field");
  field.classList.toggle("invalid", Boolean(message));
  field.querySelector(".error").textContent = message || "";
}

function validate() {
  let valid = true;

  const required = [
    ["nome", "Informe seu nome completo."],
    ["cpf", "Informe seu CPF."],
    ["telefone", "Informe seu telefone."],
    ["email", "Informe seu e-mail."],
    ["senha", "Informe uma senha."],
    ["confirmarSenha", "Confirme sua senha."],
    ["cep", "Informe o CEP."],
    ["uf", "Selecione a UF."],
    ["rua", "Informe a rua ou avenida."],
    ["numero", "Informe o número."],
    ["bairro", "Informe o bairro."],
    ["cidade", "Informe a cidade."]
  ];

  required.forEach(([id, message]) => {
    const input = document.getElementById(id);
    if (!input.value.trim()) {
      setError(input, message);
      valid = false;
    } else {
      setError(input, "");
    }
  });

  const cpf = document.getElementById("cpf");
  if (cpf.value && onlyDigits(cpf.value).length !== 11) {
    setError(cpf, "Digite um CPF com 11 números.");
    valid = false;
  }

  const phone = document.getElementById("telefone");
  if (phone.value && onlyDigits(phone.value).length < 10) {
    setError(phone, "Digite um telefone válido.");
    valid = false;
  }

  const cep = document.getElementById("cep");
  if (cep.value && onlyDigits(cep.value).length !== 8) {
    setError(cep, "Digite um CEP com 8 números.");
    valid = false;
  }

  const email = document.getElementById("email");
  if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    setError(email, "Digite um e-mail válido.");
    valid = false;
  }

  const senha = document.getElementById("senha");
  const confirmar = document.getElementById("confirmarSenha");

  if (senha.value && senha.value.length < 6) {
    setError(senha, "A senha deve ter pelo menos 6 caracteres.");
    valid = false;
  }

  if (senha.value && confirmar.value && senha.value !== confirmar.value) {
    setError(confirmar, "As senhas não coincidem.");
    valid = false;
  }

  return valid;
}

form.addEventListener("submit", (event) => {
  event.preventDefault();

  successMessage.classList.remove("show");

  if (!validate()) {
    const firstInvalid = form.querySelector(".field.invalid input, .field.invalid select");
    firstInvalid?.focus();
    return;
  }

  // Protótipo: não grava, envia para API nem persiste dados.
  successMessage.classList.add("show");
  successMessage.scrollIntoView({ behavior: "smooth", block: "center" });
});

form.querySelectorAll("input, select").forEach((input) => {
  input.addEventListener("input", () => {
    const field = input.closest(".field");
    if (field?.classList.contains("invalid")) {
      setError(input, "");
    }
  });
});
