# JM Variedades — Protótipo de Cadastro de Cliente

## Arquivos

- `index.html` — estrutura da tela.
- `style.css` — identidade visual e responsividade.
- `script.js` — máscaras, validações e confirmação simulada.
- `historia-usuario-revisada.md` — história de usuário revisada.

## Como abrir

Abra o arquivo `index.html` no navegador.

## Observação

Este é um protótipo acadêmico. O botão **Criar minha conta** não grava dados e não se conecta a banco de dados ou API.

## Identidade visual aplicada

- Preto: `#070707`
- Dourado JM: `#F5B52E`
- Dourado claro: `#FFD66B`
- Branco: `#FFFFFF`
- Fundo: `#F6F6F4`
- Linha: `#E8E8E4`
- Texto: `#161616`
- Texto secundário: `#777777`
- Sucesso: `#16875B`
- Erro: `#C94A4A`
- Tipografia: Inter
- Interface: e-commerce moderno, minimalista e comercial
- Bordas arredondadas e sombras suaves
